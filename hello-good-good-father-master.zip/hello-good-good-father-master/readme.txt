=== Good Good Father ===
Contributors: mackenly
Requires at least: 3.0
Stable tag: 1.6
Tested up to: 5.2.4

This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in a few words sung most famously by Chris Tomlin.

== Description ==

Forked from Hello Dolly. This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in a few words sung most famously by Chris Tomlin: Good Good Father. When activated you will randomly see a lyric from <cite>Good Good Father</cite> in the upper right of your admin screen on every page.
